require("common.ui.hud.assault").setup()

trx.events.on_game_start(function(is_save)
  trx.lara.holsters_visible = trx.lara.has_pistol_weapon
  if is_save then
    return
  end
  local records = trx.assault.stats.list_records()
  if #records > 1 then
    trx.music.tracks[22]:play()
  else
    trx.music.tracks[5]:play()
  end
end)

trx.events.on_flip_effect(200, function(item, timer)
  trx.music.tracks[36]:play({ mode = trx.music.PlayMode.OVERLAY })
end)
