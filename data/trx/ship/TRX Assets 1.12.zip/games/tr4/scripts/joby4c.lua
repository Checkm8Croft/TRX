trx.events.on_game_start(function(is_save)
  trx.objects.animating_13.properties.collidable = false
  trx.items[36].properties.switch_mode = trx.items.SwitchMode.HIDDEN_PICKUP
  trx.items[37].properties.switch_mode = trx.items.SwitchMode.HIDDEN_REACH
  trx.items[45].properties.switch_mode = trx.items.SwitchMode.HIDDEN_PICKUP
  trx.items[46].properties.switch_mode = trx.items.SwitchMode.HIDDEN_REACH
  trx.items[56].properties.switch_mode = trx.items.SwitchMode.HIDDEN_REACH
  trx.items[57].properties.switch_mode = trx.items.SwitchMode.HIDDEN_REACH
  trx.items[65].properties.switch_mode = trx.items.SwitchMode.HIDDEN_REACH
  trx.items[66].properties.switch_mode = trx.items.SwitchMode.HIDDEN_PICKUP
  trx.items[104].properties.switch_mode = trx.items.SwitchMode.HIDDEN_REACH
  trx.items[105].properties.switch_mode = trx.items.SwitchMode.HIDDEN_REACH
  trx.items[129].properties.switch_mode = trx.items.SwitchMode.HIDDEN_REACH
  trx.items[130].properties.switch_mode = trx.items.SwitchMode.HIDDEN_PICKUP
  trx.items[142].properties.switch_mode = trx.items.SwitchMode.HIDDEN_REACH
  trx.items[143].properties.switch_mode = trx.items.SwitchMode.HIDDEN_REACH
  trx.items[151].properties.switch_mode = trx.items.SwitchMode.HIDDEN_REACH
  trx.items[152].properties.switch_mode = trx.items.SwitchMode.HIDDEN_PICKUP
  trx.items[34].properties.pickup_mode = trx.items.PickupMode.HIDDEN
  trx.items[44].properties.pickup_mode = trx.items.PickupMode.HIDDEN
  trx.items[68].properties.pickup_mode = trx.items.PickupMode.HIDDEN
  trx.items[127].properties.pickup_mode = trx.items.PickupMode.HIDDEN
  trx.items[154].properties.pickup_mode = trx.items.PickupMode.HIDDEN
  trx.items[137].properties.pickup_mode = trx.items.PickupMode.CROWBAR

  require("tr4.expanding_blocks").initialise(
    trx.objects.raising_block_2,
    true,
    not is_save
  )
end)

require("tr4.inv_setup").apply({
  key_item_11 = { scale = 1200, offset_y = 5, rot_x = -90 },
  key_item_12 = { scale = 768, offset_y = 4, rot_x = -90 },
  puzzle_item_5 = { scale = 1200, offset_y = 23, rot_y = 90 },
  puzzle_item_6 = { scale = 512, offset_y = 5, draws_at_pivot = true },
  puzzle_item_7 = { scale = 512, offset_y = 5, draws_at_pivot = true },
  puzzle_item_8 = { scale = 512, offset_y = 5, draws_at_pivot = true },
  puzzle_item_9 = { scale = 512, offset_y = 5, draws_at_pivot = true },
})
