trx.events.on_game_start(function()
  trx.creatures.add_ally(trx.catalog.objects.monk_1)
  trx.creatures.add_ally_target(trx.catalog.objects.bandit_2)
end)
